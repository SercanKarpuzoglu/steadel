<?php
/**
 * Uninstall handler. The plugin stores no options or tables of its own, so
 * there is nothing to clean up — this file exists to satisfy the uninstall
 * contract and guard against direct access.
 *
 * @package Steadel_Low_Stock_Alerts
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
