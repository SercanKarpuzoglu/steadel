=== Steadel — Low-stock alerts & reports ===
Contributors: parsius
Tags: woocommerce, inventory, low stock, stock alerts, reports
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

See which WooCommerce products are running low, and connect to Steadel for automatic low-stock alerts and scheduled reports. EU-hosted, GDPR-first.

== Description ==

Running out of a bestseller costs you the sale — and, if you run ads, the spend that sent shoppers to an empty product page. **Steadel** warns you *before* that happens.

This plugin does two things:

1. **Shows what's running low right now.** Right inside your WordPress admin, it lists the WooCommerce products at or below your low-stock threshold — a quick, no-setup snapshot.
2. **Connects your store to Steadel** for the part a snapshot can't do: automatic **low-stock alerts** (email or Slack) when stock dips below your threshold, and **scheduled inventory reports** delivered to your inbox. Steadel checks your store every 10 minutes.

Connecting uses WooCommerce's built-in one-click authorization — you approve **read-only** access, and there are no API keys to copy. Steadel never requests write access; it reads products and inventory and stores nothing about your customers or orders.

**Why store owners in the EU choose Steadel**

* **Hosted in Germany** — your data stays in the EU. No US transfer.
* **GDPR-first** — no tracking cookies, no advertising pixels.
* **Flat, transparent pricing** — a fixed monthly price, never a cut of your ad spend.
* **Calm and written** — no upsells, no sales calls, real human email support.

Steadel is a paid service (14-day free trial, no card required); billing is handled entirely on steadel.com. This plugin itself is free and does not require a Steadel account to see your local low-stock list.

Note: Steadel's **ads guard** — automatically pausing Meta ads for products that are out of stock — is currently in **Beta** and rolling out.

Steadel is a product of Parsius.

== External services ==

This plugin can connect your store to **Steadel**, a third-party service operated by Parsius (Parsius Bilişim Danışmanlık Arge Ticaret ve Sanayi Limited Şirketi, Ankara, Turkey), hosted in Germany.

**The plugin does not contact Steadel on its own.** The low-stock list on its admin page is generated entirely from your own WooCommerce data and never leaves your site. No data is transmitted unless you click "Connect this store to Steadel".

When you click that button:

* You are taken to app.steadel.com with your site address (`home_url()`) as a URL parameter, so Steadel knows which store to connect.
* WooCommerce's own authorization screen then asks you to approve API access. If you approve, **WooCommerce** — not this plugin — generates API keys and sends them to Steadel.
* From then on, Steadel reads your products and inventory (names, SKUs, stock quantities) to send you low-stock alerts and scheduled reports. It requests Read access only, never Write, and stores nothing about your customers or orders.

You can revoke access at any time under **WooCommerce → Settings → Advanced → REST API**, or by disconnecting the store in Steadel.

Steadel is a paid service with a 14-day free trial. Terms of service: https://app.steadel.com/terms — Privacy policy: https://app.steadel.com/privacy

== Installation ==

1. Install and activate the plugin (WooCommerce must be active).
2. Open **Steadel** in the WordPress admin menu to see your low-stock products.
3. Click **Connect this store to Steadel** and approve read-only access in one click. New to Steadel? Start a free trial first, then connect.

== Frequently Asked Questions ==

= Does this plugin send my data anywhere on its own? =

No. The low-stock list is generated locally from your own WooCommerce data and is only shown in your admin. Data is shared with Steadel only after you explicitly connect your store and approve access.

= What access does Steadel get when I connect? =

Read — never Write. WooCommerce's authorization screen only offers store-wide **Read** or **Write** scopes, so the approval page lists more than Steadel actually uses (it mentions orders and customers because that is what a store-wide Read scope covers). Steadel requests **Read**, reads only products and inventory, and stores nothing about your customers or orders.

= Is a Steadel account required? =

Not for the local low-stock list. Automatic alerts and scheduled reports require a Steadel account (14-day free trial, no card required).

= Where is my data processed? =

Steadel is hosted in Germany and keeps your store data in the EU.

== Changelog ==

= 1.0.0 =
* Initial release: local low-stock report and one-click connect to Steadel.

== Upgrade Notice ==

= 1.0.0 =
Initial release.
