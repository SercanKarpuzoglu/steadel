<?php
/**
 * Plugin Name:       Steadel — Low-stock alerts & reports
 * Plugin URI:        https://app.steadel.com
 * Description:       See which products are running low right now, and connect your store to Steadel for automatic low-stock alerts and scheduled reports. EU-hosted in Germany, GDPR-first.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Parsius
 * Author URI:        https://app.steadel.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       steadel-connector
 * Requires Plugins:  woocommerce
 * WC requires at least: 6.0
 * WC tested up to:   10.9
 *
 * @package Steadel_Connector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'STEADEL_APP_URL', 'https://app.steadel.com' );

/**
 * Register the top-level Steadel admin menu.
 */
function steadel_connector_menu() {
	add_menu_page(
		__( 'Steadel', 'steadel-connector' ),
		__( 'Steadel', 'steadel-connector' ),
		'manage_woocommerce',
		'steadel-connector',
		'steadel_connector_render_page',
		'dashicons-chart-line',
		58
	);
}
add_action( 'admin_menu', 'steadel_connector_menu' );

/**
 * Fetch products at or below WooCommerce's low-stock threshold.
 *
 * @param int $limit Maximum rows to return.
 * @return array<int, array{name:string, sku:string, qty:int}>
 */
function steadel_connector_low_stock( $limit = 20 ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$threshold = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );
	$products  = wc_get_products(
		array(
			'limit'        => $limit,
			'status'       => 'publish',
			'stock_status' => 'instock',
			// Only stock-managed products can be "low"; without this filter the
			// row budget can be spent on products that don't track stock at all.
			'manage_stock' => true,
			'orderby'      => 'meta_value_num',
			'meta_key'     => '_stock', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'order'        => 'ASC',
			'return'       => 'objects',
		)
	);

	$rows = array();
	foreach ( $products as $product ) {
		if ( ! $product->managing_stock() ) {
			continue;
		}
		$qty = (int) $product->get_stock_quantity();
		if ( $qty <= $threshold ) {
			$rows[] = array(
				'name' => $product->get_name(),
				'sku'  => $product->get_sku(),
				'qty'  => $qty,
			);
		}
	}
	return $rows;
}

/**
 * Render the Steadel admin page: local low-stock report + connect calls-to-action.
 */
function steadel_connector_render_page() {
	$site        = home_url();
	$connect_url = add_query_arg( 'site', rawurlencode( $site ), STEADEL_APP_URL . '/stores/connect/woocommerce' );
	$signup_url  = STEADEL_APP_URL . '/signup';
	$wc_active   = class_exists( 'WooCommerce' );
	$low_stock   = $wc_active ? steadel_connector_low_stock() : array();
	$threshold   = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Steadel — never get caught out of stock', 'steadel-connector' ); ?></h1>
		<p style="max-width:640px;font-size:14px;">
			<?php esc_html_e( 'Steadel watches your inventory and warns you before a product runs out — with low-stock alerts and scheduled reports. Hosted in Germany, GDPR-first, no tracking.', 'steadel-connector' ); ?>
		</p>

		<?php if ( ! $wc_active ) : ?>
			<div class="notice notice-warning inline">
				<p><?php esc_html_e( 'WooCommerce is not active. Steadel connects to WooCommerce stores — activate WooCommerce to see your low-stock products here.', 'steadel-connector' ); ?></p>
			</div>
		<?php else : ?>
			<h2><?php esc_html_e( 'Running low right now', 'steadel-connector' ); ?></h2>
			<p>
				<?php
				/* translators: %d: the WooCommerce low-stock threshold. */
				echo esc_html( sprintf( __( 'Products at or below your low-stock threshold of %d.', 'steadel-connector' ), $threshold ) );
				?>
			</p>
			<?php if ( empty( $low_stock ) ) : ?>
				<p><em><?php esc_html_e( 'Nothing is low right now — nice. Connect Steadel to be told automatically the moment that changes.', 'steadel-connector' ); ?></em></p>
			<?php else : ?>
				<table class="widefat striped" style="max-width:640px;">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'steadel-connector' ); ?></th>
							<th><?php esc_html_e( 'SKU', 'steadel-connector' ); ?></th>
							<th style="text-align:right;"><?php esc_html_e( 'In stock', 'steadel-connector' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $low_stock as $row ) : ?>
							<tr>
								<td><?php echo esc_html( $row['name'] ); ?></td>
								<td><code><?php echo esc_html( $row['sku'] ? $row['sku'] : '—' ); ?></code></td>
								<td style="text-align:right;"><strong><?php echo esc_html( (string) $row['qty'] ); ?></strong></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		<?php endif; ?>

		<hr />

		<h2><?php esc_html_e( 'Get alerted automatically with Steadel', 'steadel-connector' ); ?></h2>
		<p><?php esc_html_e( 'This page is a snapshot. Steadel emails or Slacks you the moment stock dips below your threshold, and sends scheduled inventory reports — so you never have to check.', 'steadel-connector' ); ?></p>
		<p>
			<a class="button button-primary button-hero" href="<?php echo esc_url( $connect_url ); ?>" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Connect this store to Steadel', 'steadel-connector' ); ?>
			</a>
			<a class="button button-hero" href="<?php echo esc_url( $signup_url ); ?>" target="_blank" rel="noopener noreferrer" style="margin-left:8px;">
				<?php esc_html_e( 'New here? Start a free trial', 'steadel-connector' ); ?>
			</a>
		</p>
		<p style="color:#666;font-size:12px;max-width:640px;">
			<?php esc_html_e( 'Connecting uses WooCommerce\'s built-in one-click approval — no API keys to copy. WooCommerce only offers store-wide Read or Write scopes, so its approval screen lists more than Steadel uses: Steadel requests Read, never Write, and reads only products and inventory. Steadel is a product of Parsius; your store data stays in the EU. The ads-guard feature (pausing Meta ads for out-of-stock products) is currently in Beta.', 'steadel-connector' ); ?>
		</p>
	</div>
	<?php
}

/**
 * Add a "Connect" shortcut on the Plugins screen row.
 *
 * @param array<string, string> $links Existing action links.
 * @return array<string, string>
 */
function steadel_connector_action_links( $links ) {
	$url             = admin_url( 'admin.php?page=steadel-connector' );
	$connect         = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Open Steadel', 'steadel-connector' ) . '</a>';
	array_unshift( $links, $connect );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'steadel_connector_action_links' );

/**
 * Load translations.
 */
function steadel_connector_load_textdomain() {
	load_plugin_textdomain( 'steadel-connector', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'steadel_connector_load_textdomain' );
